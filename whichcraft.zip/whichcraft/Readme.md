1. Open terminal root of the package.
2. run "pip install . " without the quotes